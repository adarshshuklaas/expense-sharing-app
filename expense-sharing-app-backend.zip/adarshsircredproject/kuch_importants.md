#### Expenses -- 
- **POST** `/api/expenses`
  - Body (generic shape):
    ```json
    {
      "groupId": "<groupId>",
      "paidBy": "<payerUserId>",
      "amount": 1000,
      "splitType": "EQUAL | EXACT | PERCENT",
      "splits": [],
      "description": "Dinner"
    }
    ```
    yaha pe 3 types ke expenses use kiye hai equal exact percent teeno ke defination neeche explain kr diye hai["splitType": "EQUAL | EXACT | PERCENT",]


  - **EQUAL split**:
    ```json
    {
      "groupId": "G1",
      "paidBy": "U1",
      "amount": 900,
      "splitType": "EQUAL",
      "splits": [
        { "userId": "U1" },
        { "userId": "U2" },
        { "userId": "U3" }
      ],
      "description": "Hotel"
    }
    ```

  - **EXACT split** (must sum to `amount`):
    ```json
    {
      "groupId": "G1",
      "paidBy": "U1",
      "amount": 900,
      "splitType": "EXACT",
      "splits": [
        { "userId": "U1", "amount": 300 },
        { "userId": "U2", "amount": 300 },
        { "userId": "U3", "amount": 300 }
      ]
    }
    ```

  - **PERCENT split** (percents must sum to 100):
    ```json
    {
      "groupId": "G1",
      "paidBy": "U1",
      "amount": 1000,
      "splitType": "PERCENT",
      "splits": [
        { "userId": "U1", "percent": 50 },
        { "userId": "U2", "percent": 25 },
        { "userId": "U3", "percent": 25 }
      ]
    }
    phir se ek baar explain kr de rha 
    split types**:
- **EQUAL** – Total specified users mein barabar split hota hai.
- **EXACT** – Caller har user ke liye exact amount deta hai; ye total ke barabar hona chahiye.
- **PERCENT** – Caller har user ke liye percentage deta hai; ye 100 hona chahiye.
    ```

  ----  AAGE MAI KYA KARNE WALA HU EXPAND KRNE KE LIYE --------

  - Authentication aur authorization middleware add karenge.
  - Data ko database (e.g., PostgreSQL, MongoDB) mein persist karenge.
  - Pagination, soft deletes, aur richer querying add karenge.
  - Structured logging aur metrics add karenge.
