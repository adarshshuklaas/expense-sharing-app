const { SPLIT_TYPES } = require('../models/expenseModel')
const { expenseStore } = require('../models/expenseModel')
const { settlementStore } = require('../models/settlementModel')

// Internal: compute per-expense contributions and debts
const computeExpenseImpacts = (expense) => {
  const { amount, splitType, splits, paidBy } = expense
  const contributions = {} // userId -> net contribution (paid - owed)

  const addContribution = (userId, delta) => {
    contributions[userId] = (contributions[userId] || 0) + delta
  }

  // Payer pays full amount
  addContribution(paidBy, amount)

  if (splitType === SPLIT_TYPES.EQUAL) {
    const share = amount / splits.length
    splits.forEach(s => {
      addContribution(s.userId, -share)
    })
  } else if (splitType === SPLIT_TYPES.EXACT) {
    splits.forEach(s => {
      addContribution(s.userId, -s.amount)
    })
  } else if (splitType === SPLIT_TYPES.PERCENT) {
    splits.forEach(s => {
      const userShare = (amount * s.percent) / 100
      addContribution(s.userId, -userShare)
    })
  }

  return contributions
}

// Build raw balance matrix: who owes whom how much, before simplification
const buildRawBalanceMatrix = (groupId) => {
  const expenses = expenseStore.getExpensesByGroup(groupId)
  const matrix = {} // fromUserId -> { toUserId: amount }

  const addDebt = (from, to, amount) => {
    if (amount <= 0) return
    if (!matrix[from]) matrix[from] = {}
    matrix[from][to] = (matrix[from][to] || 0) + amount
  }

  expenses.forEach(exp => {
    const impacts = computeExpenseImpacts(exp)

    // Positive => net creditor, Negative => net debtor
    const creditors = []
    const debtors = []
    Object.entries(impacts).forEach(([userId, value]) => {
      if (value > 0.0001) creditors.push({ userId, value })
      else if (value < -0.0001) debtors.push({ userId, value: -value }) // make positive
    })

    let i = 0; let j = 0
    while (i < debtors.length && j < creditors.length) {
      const debtor = debtors[i]
      const creditor = creditors[j]
      const settled = Math.min(debtor.value, creditor.value)

      addDebt(debtor.userId, creditor.userId, settled)
      debtor.value -= settled
      creditor.value -= settled
      if (debtor.value <= 0.0001) i++
      if (creditor.value <= 0.0001) j++
    }
  })

  // Apply settlements: they reduce debts
  const settlements = settlementStore.getSettlementsByGroup(groupId)
  settlements.forEach(s => {
    if (!matrix[s.fromUserId]) matrix[s.fromUserId] = {}
    matrix[s.fromUserId][s.toUserId] = (matrix[s.fromUserId][s.toUserId] || 0) - s.amount
  })

  return matrix
}

// Simplify balances so that number of transactions is minimized
const simplifyBalances = (groupId) => {
  const matrix = buildRawBalanceMatrix(groupId)
  const net = {} // userId -> net (positive means others owe them)

  Object.entries(matrix).forEach(([from, tos]) => {
    Object.entries(tos).forEach(([to, amount]) => {
      const rounded = Math.round(amount * 100) / 100
      if (rounded <= 0) return
      net[from] = (net[from] || 0) - rounded
      net[to] = (net[to] || 0) + rounded
    })
  })

  const creditors = []
  const debtors = []

  Object.entries(net).forEach(([userId, value]) => {
    if (value > 0.0001) creditors.push({ userId, value })
    else if (value < -0.0001) debtors.push({ userId, value: -value })
  })

  const simplified = []
  let i = 0; let j = 0
  while (i < debtors.length && j < creditors.length) {
    const debtor = debtors[i]
    const creditor = creditors[j]
    const settled = Math.min(debtor.value, creditor.value)

    simplified.push({
      fromUserId: debtor.userId,
      toUserId: creditor.userId,
      amount: Math.round(settled * 100) / 100
    })

    debtor.value -= settled
    creditor.value -= settled
    if (debtor.value <= 0.0001) i++
    if (creditor.value <= 0.0001) j++
  }

  return simplified
}

const getUserSummary = (groupId, userId) => {
  const simplified = simplifyBalances(groupId)
  let totalOwes = 0
  let totalOwed = 0
  const owes = []
  const owedBy = []

  simplified.forEach(entry => {
    if (entry.fromUserId === userId) {
      totalOwes += entry.amount
      owes.push(entry)
    } else if (entry.toUserId === userId) {
      totalOwed += entry.amount
      owedBy.push(entry)
    }
  })

  totalOwes = Math.round(totalOwes * 100) / 100
  totalOwed = Math.round(totalOwed * 100) / 100

  return {
    totalOwes,
    totalOwed,
    owes,
    owedBy
  }
}

module.exports = {
  simplifyBalances,
  getUserSummary
}


