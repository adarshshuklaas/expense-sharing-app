const { v4: uuid } = require('uuid')

class Group {
  constructor ({ id = uuid(), name, memberIds = [] }) {
    this.id = id
    this.name = name
    this.memberIds = memberIds // array of userIds
  }
}

class GroupStore {
  constructor () {
    this.groups = new Map()
  }

  createGroup (payload) {
    const group = new Group(payload)
    this.groups.set(group.id, group)
    return group
  }

  getGroup (id) {
    return this.groups.get(id) || null
  }

  getAllGroups () {
    return Array.from(this.groups.values())
  }

  addMember (groupId, userId) {
    const group = this.getGroup(groupId)
    if (!group) return null
    if (!group.memberIds.includes(userId)) {
      group.memberIds.push(userId)
    }
    return group
  }
}

const groupStore = new GroupStore()

module.exports = {
  Group,
  groupStore
}


